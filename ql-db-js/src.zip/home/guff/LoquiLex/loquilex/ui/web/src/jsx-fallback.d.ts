// Placeholder to avoid editor red squiggles before `npm install`
declare module 'react' { const x: any; export = x }
declare module 'react-dom/client' { const x: any; export = x }
declare module 'zustand' { export const create: any }
declare module '@vitejs/plugin-react' { const x: any; export = x }
