from __future__ import annotations

import importlib


def test_env_overrides(monkeypatch):
    monkeypatch.setenv("LX_MAX_LINES", "123")
    monkeypatch.setenv("LX_PARTIAL_WORD_CAP", "9")
    monkeypatch.setenv("LX_SAVE_AUDIO", "flac")
    monkeypatch.setenv("LX_SAVE_AUDIO_PATH", "loquilex/out/session.flac")
    # Reload module to pick env
    from loquilex.config import defaults as mod

    importlib.reload(mod)
    assert mod.RT.max_lines == 123
    assert mod.RT.partial_word_cap == 9
    assert mod.RT.save_audio == "flac"
    assert mod.RT.save_audio_path.endswith("session.flac")
