"""Hardware detection for LoquiLex."""

from .detection import get_hardware_snapshot

__all__ = ["get_hardware_snapshot"]
